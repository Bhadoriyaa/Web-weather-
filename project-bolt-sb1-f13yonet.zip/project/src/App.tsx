import React, { useState } from 'react';
import axios from 'axios';
import { Cloud, Droplets, Wind, Search, Loader2 } from 'lucide-react';

interface WeatherData {
  name: string;
  main: {
    temp: number;
    humidity: number;
    feels_like: number;
  };
  weather: Array<{
    main: string;
    description: string;
  }>;
  wind: {
    speed: number;
  };
  sys: {
    country: string;
  };
}

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const API_KEY = '8c105305e9fac1871cce3aeb70675cfb'; // API key as a string
  
  const getWeatherBackground = (weatherMain: string) => {
    const backgrounds: Record<string, string> = {
      Clear: 'https://images.unsplash.com/photo-1601297183305-6df142704ea2?auto=format&fit=crop&w=1920',
      Clouds: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?auto=format&fit=crop&w=1920',
      Rain: 'https://images.unsplash.com/photo-1519692933481-e162a57d6721?auto=format&fit=crop&w=1920',
      Snow: 'https://images.unsplash.com/photo-1491002052546-bf38f186af56?auto=format&fit=crop&w=1920',
      default: 'https://images.unsplash.com/photo-1580193769210-b8d1c049a7d9?auto=format&fit=crop&w=1920',
    };
    
    return backgrounds[weatherMain] || backgrounds.default;
  };

  const fetchWeather = async () => {
    if (!city.trim()) return;
    
    setLoading(true);
    setError('');
    
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`
      );
      setWeather(response.data);
    } catch (err) {
      setError('City not found. Please try again.');
      setWeather(null);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchWeather();
  };

  return (
    <div className="min-h-screen w-full relative bg-gray-900 text-white">
      {weather && (
        <img
          src={getWeatherBackground(weather.weather[0].main)}
          alt="weather background"
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
      )}
      
      <div className="relative z-10 container mx-auto px-4 py-8 min-h-screen flex flex-col items-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center">
          Weather Forecast
        </h1>

        <form onSubmit={handleSubmit} className="w-full max-w-md mb-8">
          <div className="relative">
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="Enter city name..."
              className="w-full px-4 py-3 rounded-lg bg-gray-800 bg-opacity-50 backdrop-blur-sm text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full hover:bg-gray-700 transition-colors"
              disabled={loading}
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
            </button>
          </div>
        </form>

        {error && (
          <div className="w-full max-w-md p-4 mb-8 bg-red-500 bg-opacity-50 backdrop-blur-sm rounded-lg">
            {error}
          </div>
        )}

        {weather && (
          <div className="w-full max-w-2xl bg-gray-800 bg-opacity-50 backdrop-blur-sm rounded-xl p-6 md:p-8">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold mb-2">
                {weather.name}, {weather.sys.country}
              </h2>
              <p className="text-5xl font-bold mb-4">
                {Math.round(weather.main.temp)}°C
              </p>
              <p className="text-xl capitalize">
                {weather.weather[0].description}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col items-center p-4 bg-gray-700 bg-opacity-50 rounded-lg">
                <Droplets className="w-8 h-8 mb-2 text-blue-400" />
                <span className="text-lg font-semibold">Humidity</span>
                <span className="text-2xl font-bold">{weather.main.humidity}%</span>
              </div>

              <div className="flex flex-col items-center p-4 bg-gray-700 bg-opacity-50 rounded-lg">
                <Wind className="w-8 h-8 mb-2 text-green-400" />
                <span className="text-lg font-semibold">Wind Speed</span>
                <span className="text-2xl font-bold">{weather.wind.speed} m/s</span>
              </div>

              <div className="flex flex-col items-center p-4 bg-gray-700 bg-opacity-50 rounded-lg">
                <Cloud className="w-8 h-8 mb-2 text-yellow-400" />
                <span className="text-lg font-semibold">Feels Like</span>
                <span className="text-2xl font-bold">
                  {Math.round(weather.main.feels_like)}°C
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;